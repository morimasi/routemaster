export { DriverHUDModule } from './DriverHUDModule';
